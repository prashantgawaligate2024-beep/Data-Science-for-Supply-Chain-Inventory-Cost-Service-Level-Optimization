# Project Documentation - Inventory Rewired

## Business Problem
Retail Craft Pvt. Ltd. faces:
- High stock-out rates for fast-moving items
- Overstocking of slow-moving SKUs
- Inefficient inventory management
- High working capital tied up in inventory

## Solution Approach
1. **Data Integration**: Consolidated siloed ERP data
2. **ABC Classification**: Prioritized SKUs by revenue contribution
3. **Demand Analysis**: Statistical forecasting and variability assessment
4. **Optimization Model**: EOQ, ROP, and safety stock calculations
5. **Performance Validation**: Simulated 3-week performance comparison

## Key Methodologies

### ABC Analysis
- Pareto principle (80-20 rule) applied
- SKUs classified by revenue contribution
- Class A: 79% revenue, 60% items
- Class B: 14% revenue, 20% items  
- Class C: 7% revenue, 20% items

### Economic Order Quantity (EOQ)
Formula: EOQ = √(2 × Annual Demand × Ordering Cost / Holding Cost)
- Minimizes total inventory costs
- Balances ordering and holding costs
- Calculated per SKU-store combination

### Reorder Point System
Formula: ROP = (Average Daily Demand × Lead Time) + Safety Stock
- Triggers replenishment orders
- Accounts for demand variability
- Prevents stock-outs during lead time

### Safety Stock Calculation
Formula: SS = Z-score × Daily Std Dev × √Lead Time
- Buffer against demand uncertainty
- Service level dependent (A:95%, B:90%, C:85%)
- Lead time variability protection

## Implementation Plan
1. **Phase 1 (Week 1-2)**: System setup and training
2. **Phase 2 (Week 3-4)**: Pilot implementation for Class A items
3. **Phase 3 (Month 2)**: Full rollout across all SKUs
4. **Phase 4 (Month 3)**: Performance monitoring and adjustment

## Expected Benefits
- 28% reduction in inventory holding costs
- 11% improvement in service levels
- 47% reduction in stock-out incidents
- 214% ROI in first year

## Risk Mitigation
- Gradual rollout to minimize disruption
- Continuous monitoring and adjustment
- Staff training and change management
- Supplier relationship enhancement

## Success Metrics
- Fill rate improvement
- Inventory turnover increase
- Cost reduction achievement
- Service level enhancement
- Stock-out frequency reduction

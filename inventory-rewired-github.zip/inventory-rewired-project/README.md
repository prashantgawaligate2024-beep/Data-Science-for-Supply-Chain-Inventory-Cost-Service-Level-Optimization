# Inventory Rewired - Supply Chain Optimization Project

## Overview
This project simulates and optimizes inventory and replenishment decisions for Retail Craft Pvt. Ltd., a fictional retail company operating 3 urban stores in India. The goal is to reduce out-of-stock events and excess inventory holding costs by 10% over a 3-month period.

## Project Objectives
- **Primary Goal**: Reduce out-of-stock events and excess inventory costs by 10%
- **Achieved**: 28% reduction in inventory holding costs and 11% improvement in service levels
- **ROI**: 214% in first year with 3.8-month payback period

## Key Results
- **Service Level Improvement**: 80% → 91%
- **Stock-out Reduction**: 15 → 8 incidents (-47%)
- **Inventory Cost Reduction**: $25,000 → $18,000 (-28%)
- **Annual Cost Savings**: $7,000

## Repository Structure
```
├── data/                     # Raw and processed datasets
├── analysis/                 # Python analysis scripts and CSV outputs
├── visualizations/          # Charts and dashboards
├── reports/                 # Executive summary and detailed reports
├── main_analysis.py         # Complete analysis script
└── README.md               # Project documentation
```

## Data Sources
- **Sales Data**: 92 days of daily POS data across 3 stores and 10 SKUs
- **Inventory Data**: Current stock levels per store-SKU combination
- **SKU Master**: Product attributes (cost, lead time, shelf life)
- **Purchase Orders**: Historical procurement data
- **Supplier Data**: Service levels and delay rates

## Methodology
1. **Data Cleaning & Integration**: Consolidated siloed ERP data
2. **ABC Analysis**: Pareto classification for SKU prioritization
3. **Demand Analysis**: Statistical forecasting and variability assessment
4. **Inventory Optimization**: EOQ, ROP, and safety stock calculations
5. **Performance Simulation**: 3-week model validation

## Key Findings
- Class A SKUs (6 items) contribute 79% of revenue
- High demand variability (CV 0.6-0.8) requires robust safety stock
- Current inventory turnover: 22.6x annually
- 2 critical Class A items currently below reorder point

## Recommendations
1. Implement ABC-based service level targets (A:95%, B:90%, C:85%)
2. Establish systematic reorder points and EOQ calculations
3. Focus on Class A items: P1002, P1010, P1008, P1005, P1001, P1007
4. Automate reorder alerts for systematic replenishment
5. Quarterly safety stock reviews based on demand patterns

## Technology Stack
- **Python**: pandas, numpy, matplotlib for analysis
- **Tools**: Jupyter notebooks, Excel integration
- **Visualization**: Charts and executive dashboards

## Installation & Usage
```bash
# Clone the repository
git clone https://github.com/yourusername/inventory-rewired-project.git

# Install dependencies
pip install pandas numpy matplotlib datetime

# Run the main analysis
python main_analysis.py
```

## Files Description
- `main_analysis.py`: Complete inventory optimization analysis
- `data/InventoryRewired_Dataset.xlsx`: Original dataset
- `analysis/*.csv`: Processed data and results
- `visualizations/`: Charts for ABC analysis, KPI comparison, turnover heatmap

## Results Summary
| Metric | Current | Proposed | Improvement |
|--------|---------|----------|-------------|
| Service Level | 80% | 91% | +13.8% |
| Stock-out Incidents | 15 | 8 | -46.7% |
| Inventory Cost | $25,000 | $18,000 | -28% |
| ROI (Year 1) | - | 214% | New |

## Business Impact
- **Cost Savings**: $7,000 annually in reduced inventory costs
- **Revenue Impact**: ~$15,000 from improved service levels
- **Implementation Cost**: $7,000 one-time
- **Payback Period**: 3.8 months

## Next Steps
1. Implement automated reorder system
2. Establish weekly inventory reviews for Class A items
3. Develop supplier relationship improvements
4. Monitor and adjust safety stock quarterly

## Contact
For questions about this analysis, please contact the project team.

---
*This project was completed as part of the Stratify Business Analytics Bootcamp 2025*

# Inventory Rewired - Configuration File
# =====================================

# Analysis Parameters
ORDERING_COST = 50  # USD per order
HOLDING_COST_RATE = 0.20  # 20% of unit cost annually

# Service Level Targets by ABC Class
SERVICE_LEVELS = {
    'A': 0.95,  # 95% service level for Class A items
    'B': 0.90,  # 90% service level for Class B items  
    'C': 0.85   # 85% service level for Class C items
}

# Z-scores for service levels (for safety stock calculation)
Z_SCORES = {
    'A': 1.645,  # 95% service level
    'B': 1.282,  # 90% service level
    'C': 1.036   # 85% service level
}

# Simulation Parameters
SIMULATION_DAYS = 21  # 3 weeks
ANALYSIS_PERIOD_DAYS = 92  # ~3 months

# File Paths
DATA_FILE = 'data/InventoryRewired_Dataset.xlsx'
OUTPUT_DIR = 'analysis/'

# Display Settings
CURRENCY_SYMBOL = '$'
DATE_FORMAT = '%Y-%m-%d'

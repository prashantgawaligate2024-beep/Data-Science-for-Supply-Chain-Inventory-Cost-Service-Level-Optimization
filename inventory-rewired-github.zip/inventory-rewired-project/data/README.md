# Data Directory

## Original Dataset
The original dataset 'InventoryRewired_Dataset.xlsx' should be placed in this directory.

## Data Structure
The Excel file contains the following sheets:
- **Sales_data**: Daily sales transactions (92 days, 3 stores, 10 SKUs)
- **Inventory_data**: Current stock levels per store-SKU combination
- **SKU_master**: Product master data (cost, lead time, shelf life)
- **Purchase_orders**: Historical procurement data
- **Supplier_data**: Supplier performance metrics

## Data Quality
- Complete transaction history from March 1 - May 31, 2024
- 2,760 sales records across all store-SKU combinations
- No missing values in core datasets
- Consistent data formats and naming conventions

## File Size
- Original dataset: ~70KB
- Clean, structured format ready for analysis

Note: Please copy the InventoryRewired_Dataset.xlsx file to this directory before running the analysis.

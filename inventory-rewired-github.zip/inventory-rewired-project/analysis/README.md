# Analysis Directory

This directory contains the processed data and analysis results:

## Generated Files
- `abc_analysis_results.csv`: SKU classification and revenue analysis
- `inventory_management_parameters.csv`: EOQ, safety stock, reorder points
- `current_inventory_status.csv`: Current stock analysis and days of supply
- `items_needing_reorder.csv`: Items below reorder point (if any)
- `demand_analysis_by_store_sku.csv`: Demand patterns and variability
- `inventory_turnover_analysis.csv`: Turnover rates and performance metrics
- `executive_summary_metrics.csv`: Key performance indicators

## File Descriptions
Each CSV file contains processed data ready for dashboard creation, further analysis, or executive reporting.

## Usage
These files can be:
- Imported into Excel for pivot tables and dashboards
- Used in BI tools like Tableau or Power BI
- Analyzed further with Python or R
- Shared with stakeholders for decision making

Note: Files will be generated when running the main analysis script.

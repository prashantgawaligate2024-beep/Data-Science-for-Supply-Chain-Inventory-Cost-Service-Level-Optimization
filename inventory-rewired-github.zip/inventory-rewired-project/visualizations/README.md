# Visualizations Directory

This directory contains charts and visualizations generated from the analysis:

## Generated Charts
1. **ABC Analysis Pareto Chart**: Revenue contribution by SKU with cumulative percentage
2. **KPI Comparison Chart**: Current vs proposed system performance metrics
3. **Inventory Turnover Heatmap**: Annual turnover rates by store and SKU

## Chart Descriptions
- **Pareto Chart**: Shows the 80-20 principle in action with Class A items
- **KPI Comparison**: Visual comparison of service levels, stock-outs, and costs
- **Turnover Heatmap**: Identifies high and low turnover items across stores

## File Formats
Charts are generated programmatically and can be exported as:
- PNG (high resolution)
- PDF (publication quality)
- SVG (vector format)

Note: Charts will be generated when running the main analysis script.
